from setuptools import setup, Extension

# Define el módulo de extensión
cedula_lib_module = Extension('cedula_lib',
                              sources=['consulta.c'],  # Lista de archivos fuente C
                              libraries=['curl'],         # Bibliotecas requeridas (libcurl)
                              )

setup(name='cedula_lib',
      version='1.0',
      description='Módulo en C para formatear y consultar cédulas',
      ext_modules=[cedula_lib_module],  # Lista de módulos de extensión a compilar
      )
