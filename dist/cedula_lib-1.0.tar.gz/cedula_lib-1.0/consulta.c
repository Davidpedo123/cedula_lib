#include <Python.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <curl/curl.h> // Asegúrate de tener instalada la biblioteca libcurl-dev

// Función para formatear la cédula
char* formatear_cedula(char* cedula) {
    char* cedula_formateada = (char*) malloc(20 * sizeof(char));
    strcpy(cedula_formateada, cedula);

    // Lógica de formateo de cédula
    int len = strlen(cedula_formateada);
    if (len == 11) {
        sprintf(cedula_formateada, "%s-%s-%c", &cedula[0], &cedula[3], cedula[10]);
    } else if (len == 10) {
        sprintf(cedula_formateada, "0%s-%s-%c", &cedula[0], &cedula[2], cedula[9]);
    } else if (len == 9) {
        sprintf(cedula_formateada, "00%s-%s-%c", &cedula[0], &cedula[1], cedula[8]);
    }

    return cedula_formateada;
}

// Función para consultar la API con la cédula
char* consulta_cedula_docente(char* cedula) {
    // Asumiendo que PATH y URL se definen externamente
    const char* PATH = "URL_API_MINERD/{cedula}";
    CURL *curl;
    CURLcode res;
    char* resultado = NULL;

    curl = curl_easy_init();
    if (curl) {
        // Construir la URL con la cédula
        char url[255];
        sprintf(url, PATH, cedula);

        curl_easy_setopt(curl, CURLOPT_URL, url);
        curl_easy_setopt(curl, CURLOPT_HTTPGET, 1L);

        // Almacenar la respuesta en un buffer
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &resultado);

        // Realizar la solicitud HTTP
        res = curl_easy_perform(curl);

        // Verificar errores
        if (res != CURLE_OK) {
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
            resultado = "Error";
        }

        // Limpiar el objeto CURL
        curl_easy_cleanup(curl);
    }

    return resultado;
}

// Método de inicialización del módulo
static PyObject* cedula_formatear_cedula(PyObject* self, PyObject* args) {
    const char* cedula;
    if (!PyArg_ParseTuple(args, "s", &cedula)) {
        return NULL;
    }
    char* cedula_formateada = formatear_cedula(cedula);
    PyObject* resultado = Py_BuildValue("s", cedula_formateada);
    free(cedula_formateada);
    return resultado;
}

static PyObject* cedula_consulta_cedula_docente(PyObject* self, PyObject* args) {
    const char* cedula;
    if (!PyArg_ParseTuple(args, "s", &cedula)) {
        return NULL;
    }
    char* resultado_api = consulta_cedula_docente(cedula);
    PyObject* resultado = Py_BuildValue("s", resultado_api);
    free(resultado_api);
    return resultado;
}

// Definir métodos del módulo
static PyMethodDef cedula_methods[] = {
    {"formatear_cedula", cedula_formatear_cedula, METH_VARARGS, "Formatea una cédula."},
    {"consulta_cedula_docente", cedula_consulta_cedula_docente, METH_VARARGS, "Consulta la API con la cédula formateada."},
    {NULL, NULL, 0, NULL} // Terminador
};

// Inicialización del módulo
static struct PyModuleDef cedula_module = {
    PyModuleDef_HEAD_INIT,
    "cedula_lib", // Nombre del módulo
    "Módulo en C para formatear y consultar cédulas.", // Docstring
    -1,
    cedula_methods // Métodos del módulo
};

// Función de inicialización del módulo
PyMODINIT_FUNC PyInit_cedula_lib(void) {
    return PyModule_Create(&cedula_module);
}